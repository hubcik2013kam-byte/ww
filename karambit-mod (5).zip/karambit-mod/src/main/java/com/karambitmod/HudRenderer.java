package com.karambitmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

/** Rysuje "Teraz gra" ze Spotify (opcjonalnie z gradientem i paskiem postępu). */
public final class HudRenderer {
    public static final int BOX_W = 180;

    private HudRenderer() {}

    public static void render(DrawContext ctx, RenderTickCounter tick) {
        Cfg c = Cfg.I;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!c.modEnabled || !c.spotifyEnabled || !c.hudEnabled || mc.options.hudHidden || mc.player == null) return;
        Spotify.Track t = Spotify.track;
        if (t == null) return;
        draw(ctx, mc.textRenderer, t, ctx.getScaledWindowWidth(), ctx.getScaledWindowHeight());
    }

    /** Wspólne rysowanie (HUD + podgląd). */
    public static void draw(DrawContext ctx, TextRenderer tr, Spotify.Track t, int screenW, int screenH) {
        Cfg c = Cfg.I;
        float s = c.hudScale;
        int boxH = c.hudProgress ? 27 : 11;
        float x = (screenW - BOX_W * s) * c.hudX / 100f;
        float y = (screenH - boxH * s) * c.hudY / 100f;

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(x, y);
        ctx.getMatrices().scale(s, s);

        String line = (t.playing() ? "♪ " : "❚❚ ") + t.title() + " — " + t.artist();
        if (tr.getWidth(line) > BOX_W - 6) line = tr.trimToWidth(line, BOX_W - 14) + "…";

        Gui.shadow(ctx, -7, -4, BOX_W + 3, boxH + 3, 3);
        Gui.roundRect(ctx, -7, -4, BOX_W + 3, boxH + 4, 4, 0xC0101018);
        Gui.vGradient(ctx, -5, -2, 2, boxH + 4, c.hudColorA, c.hudGradient ? c.hudColorB : c.hudColorA);
        ctx.drawTextWithShadow(tr, gradient(line, c), 0, 0, 0xFFFFFFFF);

        if (c.hudProgress && t.durationMs() > 0) {
            long cur = t.currentProgress();
            float frac = Math.min(1f, (float) cur / t.durationMs());
            int barW = BOX_W - 3;
            int filled = (int) (barW * frac);
            Gui.roundRect(ctx, 0, 13, barW, 16, 1, 0xFF2A2A34);
            for (int i = 0; i < filled; i++) {
                int col = c.hudGradient ? Cfg.lerp(c.hudColorA, c.hudColorB, (float) i / barW) : c.hudColorA;
                ctx.fill(i, 13, i + 1, 16, 0xFF000000 | col);
            }
            ctx.drawTextWithShadow(tr, Text.literal(fmt(cur) + " / " + fmt(t.durationMs())), 0, 18, 0xFFAAAAAA);
        }
        ctx.getMatrices().popMatrix();
    }

    private static MutableText gradient(String s, Cfg c) {
        MutableText out = Text.empty();
        int n = Math.max(1, s.length() - 1);
        for (int i = 0; i < s.length(); i++) {
            int col = c.hudGradient ? Cfg.lerp(c.hudColorA, c.hudColorB, (float) i / n) : c.hudColorA;
            out.append(Text.literal(String.valueOf(s.charAt(i))).setStyle(Style.EMPTY.withColor(col)));
        }
        return out;
    }

    private static String fmt(long ms) {
        long sec = ms / 1000;
        return (sec / 60) + ":" + String.format("%02d", sec % 60);
    }
}

package com.karambitmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

/** Małe narzędzia do rysowania ładniejszego GUI (zaokrąglone prostokąty, cienie, gradienty). */
public final class Gui {
    public static final int ACCENT_A = 0x8A5CFF;
    public static final int ACCENT_B = 0x33CCFF;

    private Gui() {}

    /** Miesza dwa kolory (alfa ignorowana), wynik jest w pełni kryjący. */
    public static int mix(int a, int b, float t) {
        return 0xFF000000 | Cfg.lerp(a & 0xFFFFFF, b & 0xFFFFFF, t);
    }

    /** Prostokąt z lekko zaokrąglonymi rogami (promień 2 px). Kolor ARGB. */
    public static void roundRect(DrawContext c, int x1, int y1, int x2, int y2, int argb) {
        roundRect(c, x1, y1, x2, y2, 2, argb);
    }

    /** Prostokąt z zaokrąglonymi rogami o promieniu r. Rysuje bez nakładania, więc działa też z przezroczystością. */
    public static void roundRect(DrawContext c, int x1, int y1, int x2, int y2, int r, int argb) {
        int w = x2 - x1, h = y2 - y1;
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.floor(Math.sqrt(r * r - dy * dy));
            c.fill(x1 + inset, y1 + i, x2 - inset, y1 + i + 1, argb);
            c.fill(x1 + inset, y2 - i - 1, x2 - inset, y2 - i, argb);
        }
        if (y2 - r > y1 + r) c.fill(x1, y1 + r, x2, y2 - r, argb);
    }

    /** Zaokrąglony prostokąt z 1-pikselową ramką. */
    public static void framed(DrawContext c, int x1, int y1, int x2, int y2, int r, int border, int fill) {
        roundRect(c, x1, y1, x2, y2, r, border);
        roundRect(c, x1 + 1, y1 + 1, x2 - 1, y2 - 1, Math.max(0, r - 1), fill);
    }

    /** Miękki cień pod panelem. */
    public static void shadow(DrawContext c, int x1, int y1, int x2, int y2, int r) {
        for (int k = 1; k <= 5; k++) {
            int a = 0x1C - k * 4;
            roundRect(c, x1 - k, y1 - k + 2, x2 + k, y2 + k + 2, r + k, a << 24);
        }
    }

    public static void hGradient(DrawContext c, int x, int y, int w, int h, int a, int b) {
        for (int i = 0; i < w; i++) c.fill(x + i, y, x + i + 1, y + h, 0xFF000000 | Cfg.lerp(a, b, (float) i / Math.max(1, w - 1)));
    }

    public static void vGradient(DrawContext c, int x, int y, int w, int h, int a, int b) {
        for (int i = 0; i < h; i++) c.fill(x, y + i, x + w, y + i + 1, 0xFF000000 | Cfg.lerp(a, b, (float) i / Math.max(1, h - 1)));
    }

    /** Pasek gradientu z zaokrąglonymi końcami. */
    public static void pillGradient(DrawContext c, int x, int y, int w, int h, int a, int b) {
        int r = h / 2;
        for (int i = 0; i < w; i++) {
            int inset = 0;
            if (i < r) inset = r - (int) Math.floor(Math.sqrt(r * r - (r - i - 0.5) * (r - i - 0.5)));
            else if (i >= w - r) { int j = w - 1 - i; inset = r - (int) Math.floor(Math.sqrt(r * r - (r - j - 0.5) * (r - j - 0.5))); }
            if (inset * 2 >= h) continue;
            c.fill(x + i, y + inset, x + i + 1, y + h - inset, 0xFF000000 | Cfg.lerp(a, b, (float) i / Math.max(1, w - 1)));
        }
    }

    public static MutableText gradientText(String s, int a, int b) {
        MutableText out = Text.empty();
        int n = Math.max(1, s.length() - 1);
        for (int i = 0; i < s.length(); i++) {
            out.append(Text.literal(String.valueOf(s.charAt(i))).setStyle(Style.EMPTY.withColor(Cfg.lerp(a, b, (float) i / n)).withBold(true)));
        }
        return out;
    }
}

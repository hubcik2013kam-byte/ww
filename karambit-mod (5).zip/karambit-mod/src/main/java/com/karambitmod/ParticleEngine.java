package com.karambitmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Arm;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/**
 * Generuje latające cząsteczki o wybranym kształcie wokół miecza w ręce,
 * wskazywanego bloku albo gracza. Używa zwykłych cząsteczek vanilla (po stronie klienta),
 * więc działa też na serwerach bez moda.
 */
public final class ParticleEngine {
    private static long age = 0;
    private static final Random RND = new Random();

    // wierzchołki krawędzi sześcianu
    private static final double[][] CUBE_EDGES = buildCube();

    private ParticleEngine() {}

    private static double[][] buildCube() {
        double[][] e = new double[12][6];
        int k = 0;
        for (int v = 0; v < 8; v++) {
            for (int axis = 0; axis < 3; axis++) {
                if ((v & (1 << axis)) == 0) {
                    int w = v | (1 << axis);
                    e[k][0] = (v & 1) * 2 - 1; e[k][1] = ((v >> 1) & 1) * 2 - 1; e[k][2] = ((v >> 2) & 1) * 2 - 1;
                    e[k][3] = (w & 1) * 2 - 1; e[k][4] = ((w >> 1) & 1) * 2 - 1; e[k][5] = ((w >> 2) & 1) * 2 - 1;
                    k++;
                }
            }
        }
        return e;
    }

    public static void tick(MinecraftClient mc) {
        Cfg c = Cfg.I;
        if (!c.modEnabled || !c.particlesEnabled || mc.player == null || mc.world == null || mc.isPaused()) return;
        ClientPlayerEntity p = mc.player;
        if (c.onlyWithSword && !p.getMainHandStack().isIn(ItemTags.SWORDS)) return;
        age++;

        // --- punkt środka ---
        float yaw = p.getYaw() * ((float) Math.PI / 180f);
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);       // przód (poziomo)
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);      // prawo
        Vec3d center;
        switch (c.anchor) {
            case TARGET_BLOCK -> {
                if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK) {
                    center = Vec3d.ofCenter(((BlockHitResult) mc.crosshairTarget).getBlockPos());
                } else return;
            }
            case PLAYER -> center = new Vec3d(p.getX(), p.getY() + p.getHeight() * 0.55, p.getZ());
            default -> {
                double side = mc.options.getMainArm().getValue() == Arm.RIGHT ? 1 : -1;
                Vec3d look = p.getRotationVec(1f);
                center = p.getEyePos()
                        .add(rx * 0.40 * side, -0.35, rz * 0.40 * side)
                        .add(look.multiply(0.65));
            }
        }

        int n = c.particleCount;
        double spin = age * 0.035 * c.particleSpeed;
        for (int i = 0; i < n; i++) {
            double u = ((double) i / n + age * 0.02 * c.particleSpeed) % 1.0;
            double[] l = localPoint(c.particleShape, u, i, n);        // (prawo, góra, przód)
            double a = l[0], b = l[1], f = l[2];
            if (c.particleShape != Cfg.PShape.LINE) {                 // obrót wokół osi pionowej
                double ca = Math.cos(spin), sa = Math.sin(spin);
                double na = a * ca - f * sa;
                double nf = a * sa + f * ca;
                a = na; f = nf;
            }
            double R = c.particleRadius;
            double x = center.x + (rx * a + fx * f) * R;
            double y = center.y + b * R;
            double z = center.z + (rz * a + fz * f) * R;

            float g = (float) (1.0 - Math.abs(2 * ((u + age * 0.004) % 1.0) - 1.0));
            int color = c.particleGradient ? Cfg.lerp(c.particleColorA, c.particleColorB, g) : c.particleColorA;
            ParticleEffect eff = switch (c.particleType) {
                case DUST -> new DustParticleEffect(color, c.particleSize);
                case END_ROD -> ParticleTypes.END_ROD;
                case FLAME -> ParticleTypes.FLAME;
                case SOUL_FIRE -> ParticleTypes.SOUL_FIRE_FLAME;
                case ELECTRIC_SPARK -> ParticleTypes.ELECTRIC_SPARK;
                case HAPPY_VILLAGER -> ParticleTypes.HAPPY_VILLAGER;
            };
            mc.world.addParticleClient(eff, x, y, z, 0, 0, 0);
        }
    }

    /** Punkt kształtu w jednostkowych współrzędnych (prawo, góra, przód). u = 0..1 położenie na krzywej. */
    private static double[] localPoint(Cfg.PShape s, double u, int i, int n) {
        double t = u * Math.PI * 2;
        switch (s) {
            case ORBIT:
                return new double[]{Math.cos(t), Math.sin(t * 3) * 0.08, Math.sin(t)};
            case HELIX: {
                double ang = t * 3;
                return new double[]{Math.cos(ang) * 0.7, u * 2 - 1, Math.sin(ang) * 0.7};
            }
            case RING:
                return new double[]{Math.cos(t), Math.sin(t), 0};
            case STAR: {
                double k = u * 5;
                int seg = (int) Math.floor(k);
                double fr = k - seg;
                double[] v0 = starVertex(seg), v1 = starVertex(seg + 1);
                return new double[]{v0[0] + (v1[0] - v0[0]) * fr, v0[1] + (v1[1] - v0[1]) * fr, 0};
            }
            case HEART: {
                double a = 16 * Math.pow(Math.sin(t), 3) / 16.0;
                double b = (13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)) / 16.0;
                return new double[]{a, b, 0};
            }
            case CUBE: {
                double k = u * 12;
                int e = Math.min(11, (int) Math.floor(k));
                double fr = k - e;
                double[] ed = CUBE_EDGES[e];
                double sc = 0.7;
                return new double[]{(ed[0] + (ed[3] - ed[0]) * fr) * sc, (ed[1] + (ed[4] - ed[1]) * fr) * sc, (ed[2] + (ed[5] - ed[2]) * fr) * sc};
            }
            case SPHERE: {
                double x = RND.nextGaussian(), y = RND.nextGaussian(), z = RND.nextGaussian();
                double len = Math.max(1e-6, Math.sqrt(x * x + y * y + z * z));
                return new double[]{x / len, y / len, z / len};
            }
            case CLOUD: {
                double x, y, z;
                do { x = RND.nextDouble() * 2 - 1; y = RND.nextDouble() * 2 - 1; z = RND.nextDouble() * 2 - 1; }
                while (x * x + y * y + z * z > 1);
                return new double[]{x, y, z};
            }
            case LINE:
                return new double[]{Math.sin(u * 12 + age * 0.2) * 0.06, Math.cos(u * 12 + age * 0.2) * 0.06, u * 2.2};
            default:
                return new double[]{0, 0, 0};
        }
    }

    private static double[] starVertex(int j) {
        double ang = Math.PI / 2 + (j % 5) * (4 * Math.PI / 5);   // gwiazda pięcioramienna (pentagram)
        return new double[]{Math.cos(ang), Math.sin(ang)};
    }
}
